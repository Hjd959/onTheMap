//
//  LoginViewController.swift
//  OnTheMapApp
//
//  Created by عبدالوهاب العنزي on 05/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var password: UITextField!

    
    

    //   to show activityIndicator on the view
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var loginButton: UIButton!


    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        // layer design button
    loginButton.layer.cornerRadius = 4


    }



    
    // Login Action
    @IBAction func loginButton(_ sender: Any)
    {
        actionActivityIndicator(isProcess: true)

        // to check the username and password are not Empty ، else complet login

        if userName.text == "" || password.text == "" {
            
            
            
            
            // alert message
            
            let alertController = UIAlertController(title: "error!", message: "Please Enter your Email and password.", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
            actionActivityIndicator(isProcess: false)
            
            // layer Color for TextField
            
            userName.layer.borderColor = UIColor.red.cgColor
            userName.layer.borderWidth = 1.0
            password.layer.borderColor = UIColor.red.cgColor
            password.layer.borderWidth = 1.0
            
        } else {

            APICalls.login(username: userName.text!, password: password.text!, completion: handleloginResponse(succes:sessionID:error:))
        }
    }



    // rigester Action
    @IBAction func signUpButton(_ sender: Any) {
        let url = URL(string: "https://auth.udacity.com/sign-up?next=https://classroom.udacity.com/authenticated")!
        UIApplication.shared.open( url , options: [:], completionHandler: nil)
    }
    
    
    
    
    //  Response handler
    func handleloginResponse(succes:Bool,sessionID: String,error: Error?){
        actionActivityIndicator(isProcess: false)
        guard error == nil else {
            let alertController = UIAlertController(title: "error!", message: "Network error" , preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        
        // if data = data

        print(succes)
        if succes {
            DispatchQueue.main.async {
                self.performSegue(withIdentifier: "ShowMap", sender: self)
            }
            arrayOfStudentsLocations.uniqueKey = sessionID
            APICalls.getStudentInfo(completion: { (error) in
                guard error == nil else {
                    let alertController = UIAlertController(title: "error!", message: "Network error, Please try again!" , preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    self.present(alertController, animated: true, completion: nil)
                    return
                }
            })
        } else {
            let alertController = UIAlertController(title: "error!", message: "Error Email or password" , preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
    // hide the keyboard when user touch the view
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    
    
    
    //  Activity Action
    func actionActivityIndicator (isProcess:Bool) {
        DispatchQueue.main.async {
            if isProcess {
                self.activityIndicator.startAnimating()
            } else {
                self.activityIndicator.stopAnimating()
            }
            self.userName.isUserInteractionEnabled = !isProcess
            self.password.isUserInteractionEnabled = !isProcess
            self.loginButton.isEnabled = !isProcess
        }
    }

}
    
    

