//
//  LocationsTableViewCell.swift
//  OnTheMapApp
//
//  Created by عبدالوهاب العنزي on 11/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit

class LocationsTableViewCell: UITableViewCell {
    @IBOutlet weak var studentURL: UILabel!
    @IBOutlet weak var StudentName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
