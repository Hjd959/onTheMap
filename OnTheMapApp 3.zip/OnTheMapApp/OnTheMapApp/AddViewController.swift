//
//  AddLocationsViewController.swift
//  OnTheMapApp
//
//  Created by عبدالوهاب العنزي on 11/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit
import CoreLocation
import NotificationCenter
class AddLocationsViewController: UIViewController {
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var url: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var latitude:Double?
    var longitude:Double?
    
    @IBAction func findLocation(_ sender: Any) {
        // to check the location and url are not Empty
        
        if location.text == "" || url.text == "" {
            
            // alert message
            
            let alertController = UIAlertController(title: "error!", message: "Please Enter your location and URL ", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
            
            // layer Color for TextField
            
            location.layer.borderColor = UIColor.red.cgColor
            location.layer.borderWidth = 1.0
            url.layer.borderColor = UIColor.red.cgColor
            url.layer.borderWidth = 1.0
            
            
        } else {
            activityIndicator.startAnimating()
            let geoCoder = CLGeocoder()
            geoCoder.geocodeAddressString(location.text!) { (placemarks, error) in
                guard let placemarks = placemarks,let locationCoordinate = placemarks.first?.location
                    else {
                        let alertController = UIAlertController(title: "error!", message: "Please check your connection or enter correct city name", preferredStyle: .alert)
                        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(defaultAction)
                        self.present(alertController, animated: true, completion: nil)
                        return
                }
                
                self.latitude = locationCoordinate.coordinate.latitude
                self.longitude = locationCoordinate.coordinate.longitude
                self.activityIndicator.stopAnimating()
                
                // Identifier
                
                self.performSegue(withIdentifier: "ShowLocationOnMap", sender: nil)
            }
        }
    }
    
    
    // Cancel Action
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as! MapWithPinViewController
        controller.latitude = self.latitude
        controller.longitude = self.longitude
        controller.mapString = self.location.text
        controller.url = self.url.text
    }
    
    
    // hide the keyboard when user touch the view
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
